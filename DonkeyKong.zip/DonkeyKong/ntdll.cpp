#include "stdafx.h"
#include "ntdll.h"


ntdll::ntdll()
{
}


ntdll::~ntdll()
{
}
