#include "stdafx.h"
#include "GetWindowsVersion.h"


GetWindowsVersion::GetWindowsVersion()
{
}


GetWindowsVersion::~GetWindowsVersion()
{
}
